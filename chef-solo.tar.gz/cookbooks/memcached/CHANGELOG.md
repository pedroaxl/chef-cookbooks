## v1.0.2:

* [COOK-1081] - support for centos/rhel

## v1.0.0:

* [COOK-706] - Additional info in README
* [COOK-828] - Package for RHEL systems

## v0.10.4:

* Current released version
