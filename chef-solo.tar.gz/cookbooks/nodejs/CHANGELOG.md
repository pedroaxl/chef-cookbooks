## v1.0.1:

 * fixed bug that prevented overwritting the node/npm versions (moved the `src_url`s as local variables instead of attributes) - thanks @johannesbecker
 * updated the default versions to the latest node/npm

## v1.0.0:

* added packages installation support thanks to Nathan L Smith
