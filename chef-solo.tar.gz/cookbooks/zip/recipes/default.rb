#
# Cookbook Name:: zip
# Recipe:: default
#
# Copyright 2012, Pedro Axelrud
#

package "unzip" 
package "zip"

