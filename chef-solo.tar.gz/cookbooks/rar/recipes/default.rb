#
# Cookbook Name:: rar
# Recipe:: default
#
# Copyright 2012, Pedro Axelrud
#

package "unrar" 
package "rar"

