chef-cookbooks
==============

Those are the chef cookbooks I use in my projects, feel free to use it in case you also need some of them.

Just one or two were really created by myself, most of them were just customized.

I also include a tar file in this repo in case you want to set it with chef-solo.


