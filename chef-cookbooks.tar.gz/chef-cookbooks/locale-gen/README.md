Description
===========

Adds new locales and generates them

Requirements
============

Tested on Debian Squeeze

Attributes
==========

* `node[:localegen][:lang]` - is an array of locales you wish to add and generate. 

Usage
=====

Include the default recipe in your run list.
